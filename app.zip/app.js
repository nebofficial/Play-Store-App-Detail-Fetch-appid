import express from 'express';
import gplay from 'google-play-scraper';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;
const filePath = path.join(__dirname, 'app.json');

// Initialize app.json if it doesn't exist
if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify([], null, 4));
}

// Serve static files from public directory
app.use(express.static(path.join(__dirname, 'public')));

// Root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route to fetch app details and store in app.json
app.get('/app/:appId', async (req, res) => {
    const { appId } = req.params;

    try {
        // Fetch app details
        const appDetails = await gplay.app({ appId });
        
        if (!appDetails || Object.keys(appDetails).length === 0) {
            throw new Error('No data fetched from Google Play.');
        }

        // Read existing data with error handling
        let existingData = [];
        try {
            const fileContent = fs.readFileSync(filePath, 'utf8');
            existingData = fileContent ? JSON.parse(fileContent) : [];
        } catch (readError) {
            console.warn('Error reading app.json, initializing new array:', readError);
            existingData = [];
        }

        // Add new data
        existingData.push({
            ...appDetails,
            fetchedAt: new Date().toISOString()
        });

        // Save updated data
        fs.writeFileSync(filePath, JSON.stringify(existingData, null, 4));
        console.log('Data saved successfully');

        res.json(appDetails);
    } catch (error) {
        console.error('Error:', error.message);
        res.status(500).json({ error: error.message });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});